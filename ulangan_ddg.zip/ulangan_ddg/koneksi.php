<?php
$koneksi = new mysqli('localhost', 'root', '', 'pendaftaran');
if ($koneksi) {
    // echo "Koneksi Berhasil";
}else{
    echo $koneksi->error;
}

?>