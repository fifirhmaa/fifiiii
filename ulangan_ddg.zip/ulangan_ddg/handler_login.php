<?php

$email = $_POST['email'];
$password = $_POST['password'];

$koneksi = new mysqli('localhost', 'root', '', 'pendaftaran');
if ($koneksi) {
    echo "koneksi berhasil";
}else { 
    echo $koneksi->error;
} 

$insert = $koneksi->query("INSERT INTO pengguna 
(email, password)
values
('$email', '$password')
");

if ($insert) {
    echo "Insert Data Berhasil";
}else {
    echo"Gagal Insert Data";
}


?>